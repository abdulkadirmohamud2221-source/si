/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - About SiHub Page
 * Grounded in approved Organizational Identity, Vision, Mission, and Core Values.
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { useCmsPage } from '../../hooks/useCmsPage';
import { CmsMedia } from '../common/CmsMedia';
import {
  Target,
  Eye,
  CheckCircle2,
  Users,
  Compass,
  ArrowRight,
  Sparkles,
  ShieldCheck,
  HeartHandshake,
  Lightbulb,
  Leaf,
  GraduationCap
} from 'lucide-react';

type AboutPageContent = {
  slug?: string;
  title?: string | null;
  summary?: string | null;
  whoWeAre?: { eyebrow?: string | null; heading?: string | null; tagline?: string | null; description?: string | null; body?: string | null; image?: string | null; imageType?: 'image' | 'video'; imageAlt?: string | null; imageCaption?: string | null; video?: string | null; videoAlt?: string | null; videoCaption?: string | null };
  principlesEyebrow?: string | null;
  principlesHeading?: string | null;
  vision?: { label?: string | null; heading?: string | null; description?: string | null; footer?: string | null };
  mission?: { label?: string | null; heading?: string | null; description?: string | null; footer?: string | null };
  coreValuesTitle?: string | null;
  coreValuesDescription?: string | null;
  coreValues?: { num?: string | null; title?: string | null; desc?: string | null }[] | null;
  teamEyebrow?: string | null;
  teamTitle?: string | null;
  teamDescription?: string | null;
  team?: { name?: string | null; role?: string | null; location?: string | null; bio?: string | null; image?: string | null; imageType?: 'image' | 'video'; imageAlt?: string | null; imageCaption?: string | null }[] | null;
  banner?: { title?: string | null; description?: string | null; image?: string | null; imageType?: 'image' | 'video'; imageAlt?: string | null; imageCaption?: string | null; video?: string | null; videoAlt?: string | null; videoCaption?: string | null; exploreAction?: string | null; partnerAction?: string | null };
};

export const About: React.FC = () => {
  const { navigateTo } = useApp();
  const { page: aboutPage } = useCmsPage<AboutPageContent>('about');

  const coreValues = [
    {
      num: '01',
      title: 'Grassroots Innovation',
      desc: 'Fostering innovation that addresses real community needs from the ground up.',
      icon: <Lightbulb className="w-5 h-5 text-amber-500" />
    },
    {
      num: '02',
      title: 'Inclusivity',
      desc: 'Ensuring opportunities are accessible to all, especially women, youth, and marginalized groups.',
      icon: <Users className="w-5 h-5 text-cyan-500" />
    },
    {
      num: '03',
      title: 'Digital Empowerment',
      desc: 'Equipping the next generation with future-ready skills, digital knowledge, and tools.',
      icon: <GraduationCap className="w-5 h-5 text-indigo-500" />
    },
    {
      num: '04',
      title: 'Youth Empowerment',
      desc: 'Unlocking the potential of youth to become leaders, entrepreneurs, and changemakers.',
      icon: <Sparkles className="w-5 h-5 text-emerald-500" />
    },
    {
      num: '05',
      title: 'Collaboration',
      desc: 'Building partnerships across government, private sector, academia, and civil society.',
      icon: <HeartHandshake className="w-5 h-5 text-blue-500" />
    },
    {
      num: '06',
      title: 'Sustainability',
      desc: 'Creating solutions that generate long-term social, environmental, and economic impact.',
      icon: <Leaf className="w-5 h-5 text-teal-500" />
    },
    {
      num: '07',
      title: 'Integrity',
      desc: 'Operating with transparency, accountability, and ethical excellence in all initiatives.',
      icon: <ShieldCheck className="w-5 h-5 text-rose-500" />
    }
  ];

  const team = [
    {
      name: 'Eng. Abdullahi Warsame',
      role: 'Executive Director & Chief Systems Architect',
      location: 'Mogadishu Headquarters',
      bio: 'Enterprise systems specialist and former advisor on national digital infrastructure.',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80'
    },
    {
      name: 'Fadumo Ahmed Noor',
      role: 'Head of Governance & Institutional Partnerships',
      location: 'Mogadishu & Regional Hubs',
      bio: 'Public policy strategist coordinating university sandboxes and multilateral agency grants.',
      image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=300&auto=format&fit=crop&q=80'
    },
    {
      name: 'Dr. Hassan Ali Geedi',
      role: 'Director of Renewable Technology & AgriTech Labs',
      location: 'Hargeisa & Garowe Hubs',
      bio: 'PhD researcher on extreme-heat battery chemistry, solar micro-irrigation, and arid soil sensors.',
      image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80'
    },
    {
      name: 'Sharmarke Abdi Liban',
      role: 'Director of Incubation & Acceleration',
      location: 'Mogadishu MakerSpace',
      bio: 'Former venture accelerator lead who has mentored over 50 startups to commercial sustainability.',
      image: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=300&auto=format&fit=crop&q=80'
    }
  ];
  const displayedValues = aboutPage?.coreValues?.map((value, index) => ({
    ...coreValues[index % coreValues.length],
    ...value,
    num: value.num ?? String(index + 1).padStart(2, '0'),
    icon: coreValues[index % coreValues.length].icon
  })) ?? coreValues;
  const displayedTeam = aboutPage?.team?.map((member, index) => ({
    ...(team[index] ?? team[0]),
    ...member
  })) ?? team;
  const whoWeAre = aboutPage?.whoWeAre;
  const vision = aboutPage?.vision;
  const mission = aboutPage?.mission;
  const banner = aboutPage?.banner;

  return (
    <div className="space-y-20 py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* 1. Who We Are / Strategic Identity Section */}
      <section id="who-we-are" className="scroll-mt-28 space-y-8">
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <span className="text-xs font-bold uppercase tracking-widest text-cyan-600 bg-cyan-50 px-3 py-1 rounded-full border border-cyan-100">
            {whoWeAre?.eyebrow ?? 'About Somali Innovation Hub'}
          </span>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 font-heading tracking-tight">
            {whoWeAre?.heading ?? aboutPage?.title ?? 'Who We Are'}
          </h1>
          <div className="p-6 rounded-2xl bg-gradient-to-r from-cyan-900 via-slate-900 to-emerald-950 text-white shadow-xl text-left sm:text-center space-y-2 border border-slate-800">
            <p className="text-lg sm:text-xl font-bold font-heading text-cyan-300">
              {whoWeAre?.tagline ?? 'Grassroots Innovation. Inclusive Opportunities. Digital Transformation.'}
            </p>
            <p className="text-sm sm:text-base text-slate-200 leading-relaxed font-medium">
              {whoWeAre?.description ?? 'Empowering communities, connecting innovators, and transforming Somalia through inclusive innovation.'}
            </p>
          </div>
          <p className="text-base text-slate-600 leading-relaxed pt-2">
            {whoWeAre?.body ?? (aboutPage?.summary || 'Somali Innovation Hub (SiHub) is the parent organization and complete national innovation ecosystem for Somalia. SiHub encompasses the Innovation Lab, SiHub Institute (educational and workforce development division), Startup Hub, incubation programs, community networks, and nationwide technology initiatives.')}
          </p>
          <CmsMedia src={whoWeAre?.image} kind={whoWeAre?.imageType ?? 'image'} alt={whoWeAre?.imageAlt ?? ''} caption={whoWeAre?.imageCaption ?? undefined} className="mx-auto max-h-80 w-full rounded-2xl object-cover" />
          <CmsMedia src={whoWeAre?.video} kind="video" alt={whoWeAre?.videoAlt ?? ''} caption={whoWeAre?.videoCaption ?? undefined} className="mx-auto max-h-96 w-full rounded-2xl object-cover" />
        </div>
      </section>

      {/* 2. Vision & Mission Section */}
      <section id="vision-mission" className="scroll-mt-28 space-y-8">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <span className="text-xs font-bold uppercase tracking-widest text-emerald-600">
              {aboutPage?.principlesEyebrow ?? 'Guiding Principles'}
          </span>
          <h2 className="text-3xl font-extrabold text-slate-900 font-heading">
            {aboutPage?.principlesHeading ?? 'Our Vision & Mission'}
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Vision Card */}
          <div className="p-8 sm:p-10 rounded-3xl bg-gradient-to-br from-cyan-950 to-slate-900 text-white shadow-xl space-y-5 border border-cyan-900/50 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center border border-cyan-400/30">
                <Eye className="w-6 h-6" />
              </div>
              <span className="text-xs font-bold uppercase tracking-wider text-cyan-300 block">
                {vision?.label ?? 'Our Vision'}
              </span>
              <h3 className="text-xl sm:text-2xl font-bold font-heading text-white">
                {vision?.heading ?? 'A Leading Centre for Grassroots Social Innovation'}
              </h3>
              <p className="text-sm text-slate-200 leading-relaxed font-normal">
                {vision?.description ?? 'To become a leading centre for grassroots social innovation and entrepreneurship in Somalia, fostering an inclusive and digitally empowered society where young people and communities have the knowledge, skills, opportunities, and resources to innovate, lead, and drive sustainable positive change.'}
              </p>
            </div>
            <div className="pt-4 border-t border-cyan-800/40 text-xs text-cyan-300/80 font-mono">
              {vision?.footer ?? 'Aligned with National Sustainable Development Goals'}
            </div>
          </div>

          {/* Mission Card */}
          <div className="p-8 sm:p-10 rounded-3xl bg-gradient-to-br from-emerald-950 to-slate-900 text-white shadow-xl space-y-5 border border-emerald-900/50 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-400/30">
                <Target className="w-6 h-6" />
              </div>
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-300 block">
                {mission?.label ?? 'Our Mission'}
              </span>
              <h3 className="text-xl sm:text-2xl font-bold font-heading text-white">
                {mission?.heading ?? 'Strengthening Grassroots Ecosystems'}
              </h3>
              <p className="text-sm text-slate-200 leading-relaxed font-normal">
                {mission?.description ?? "To strengthen Somalia's grassroots social innovation ecosystem by promoting inclusive digital transformation, empowering young people, nurturing entrepreneurship, and supporting community-driven solutions that address societal challenges and create sustainable social and economic impact."}
              </p>
            </div>
            <div className="pt-4 border-t border-emerald-800/40 text-xs text-emerald-300/80 font-mono">
              {mission?.footer ?? 'Action-Oriented • Community-Led • Impact-Driven'}
            </div>
          </div>
        </div>
      </section>

      {/* 3. Core Values Section */}
      <section id="core-values" className="scroll-mt-28 space-y-8">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <span className="text-xs font-bold uppercase tracking-widest text-cyan-600">
            Organizational Foundations
          </span>
          <h2 className="text-3xl font-extrabold text-slate-900 font-heading">
            {aboutPage?.coreValuesTitle ?? 'Our 7 Core Values'}
          </h2>
          <p className="text-sm text-slate-600">
            {aboutPage?.coreValuesDescription ?? 'The fundamental beliefs and principles that guide every decision, program, and partnership at Somali Innovation Hub.'}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {displayedValues.map((v) => (
            <div
              key={v.num}
              className="p-6 rounded-2xl bg-white border border-slate-200/90 shadow-xs hover:shadow-md hover:border-cyan-200 transition-all flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                    {v.icon}
                  </div>
                  <span className="text-xs font-mono font-bold text-slate-300">
                    {v.num}
                  </span>
                </div>
                <h3 className="text-base font-bold text-slate-900 font-heading">
                  {v.title}
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {v.desc}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. Our Team Section */}
      <section id="our-team" className="scroll-mt-28 space-y-8">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <span className="text-xs font-bold uppercase tracking-widest text-emerald-600">
            {aboutPage?.teamEyebrow ?? 'Executive Leadership & Stewards'}
          </span>
          <h2 className="text-3xl font-extrabold text-slate-900 font-heading">
            {aboutPage?.teamTitle ?? 'Our Team'}
          </h2>
          <p className="text-sm text-slate-600">
            {aboutPage?.teamDescription ?? "Passionate innovators, researchers, and ecosystem builders leading SiHub's mission across Somalia."}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {displayedTeam.map((member, i) => (
            <div
              key={i}
              className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-md transition-shadow flex flex-col"
            >
              <CmsMedia src={member.image ?? ''} kind={aboutPage?.team?.[i]?.imageType ?? 'image'} alt={aboutPage?.team?.[i]?.imageAlt ?? member.name ?? ''} caption={aboutPage?.team?.[i]?.imageCaption ?? undefined} className="h-48 w-full object-cover" />
              <div className="p-5 space-y-2 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 font-heading">
                    {member.name}
                  </h3>
                  <div className="text-[11px] font-semibold text-cyan-700">
                    {member.role}
                  </div>
                  <div className="text-[10px] text-slate-400">
                    {member.location}
                  </div>
                  <p className="text-xs text-slate-600 pt-2 leading-relaxed">
                    {member.bio}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Action Banner */}
      <section className="p-8 sm:p-10 rounded-3xl bg-slate-900 text-white flex flex-col sm:flex-row items-center justify-between gap-6 shadow-xl">
        <CmsMedia src={banner?.image} kind={banner?.imageType ?? 'image'} alt={banner?.imageAlt ?? ''} caption={banner?.imageCaption ?? undefined} className="max-h-48 w-full rounded-xl object-cover sm:max-w-xs" />
        <CmsMedia src={banner?.video} kind="video" alt={banner?.videoAlt ?? ''} caption={banner?.videoCaption ?? undefined} className="max-h-48 w-full rounded-xl object-cover sm:max-w-xs" />
        <div className="space-y-2 text-center sm:text-left">
          <h3 className="text-xl sm:text-2xl font-bold font-heading">
            {banner?.title ?? 'Join the Somali Innovation Ecosystem'}
          </h3>
          <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
            {banner?.description ?? 'Whether you are an aspiring student, a grassroots founder, or a prospective global partner, SiHub has a pathway for you.'}
          </p>
        </div>
        <div className="flex flex-wrap gap-3 shrink-0">
          <button
            onClick={() => navigateTo('programs')}
            className="px-5 py-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-colors flex items-center gap-2"
          >
            <span>{banner?.exploreAction ?? 'Explore Programmes'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
          <button
            onClick={() => navigateTo('partnerships')}
            className="px-5 py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs border border-white/20 transition-colors"
          >
            {banner?.partnerAction ?? 'Partner With Us'}
          </button>
        </div>
      </section>
    </div>
  );
};

