export const canTransitionSubmission = (currentStatus: string, nextStatus: string, type: string) => {
  if (currentStatus === 'PENDING') return nextStatus === 'APPROVED' || nextStatus === 'REJECTED';
  return ['visitor-request', 'event-registration'].includes(type) && currentStatus === 'APPROVED' && nextStatus === 'COMPLETED';
};

export const publicVisitorTrackingInfo = (submission: {
  referenceCode: string;
  status: string;
  createdAt: Date;
  payload: unknown;
}) => {
  const payload = submission.payload && typeof submission.payload === 'object' && !Array.isArray(submission.payload)
    ? submission.payload as Record<string, unknown>
    : {};
  const pass = payload.visitorPass && typeof payload.visitorPass === 'object' && !Array.isArray(payload.visitorPass)
    ? payload.visitorPass as Record<string, unknown>
    : null;

  return {
    referenceCode: submission.referenceCode,
    status: submission.status,
    createdAt: submission.createdAt,
    payload: {
      fullName: payload.fullName,
      organization: payload.organization,
      hubLocation: payload.hubLocation,
      requestedDate: payload.requestedDate,
      timeSlot: payload.timeSlot,
      assignedHost: payload.assignedHost,
      visitorPass: pass ? {
        passNumber: pass.passNumber,
        assignedHost: pass.assignedHost,
        securityClearanceCode: pass.securityClearanceCode,
        issuedAt: pass.issuedAt
      } : null
    }
  };
};