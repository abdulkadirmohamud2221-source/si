import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const envExample = readFileSync(new URL('../.env.example', import.meta.url), 'utf8');
const prismaSchema = readFileSync(new URL('../prisma/schema.prisma', import.meta.url), 'utf8');

test('database template defines one safe URL for each Prisma datasource setting', () => {
  for (const key of ['DATABASE_URL', 'DIRECT_URL']) {
    const declarations = envExample.split(/\r?\n/).filter(line => line.startsWith(`${key}=`));
    assert.equal(declarations.length, 1, `${key} must be declared exactly once`);

    const value = declarations[0].slice(key.length + 1).replace(/^"|"$/g, '');
    const url = new URL(value);
    assert.equal(url.protocol, 'postgresql:');
    assert.equal(url.hostname, 'localhost');
    assert.equal(url.username, 'sihub');
    assert.equal(url.password, 'replace-me');
  }

  assert.match(prismaSchema, /url\s*=\s*env\("DATABASE_URL"\)/);
  assert.match(prismaSchema, /directUrl\s*=\s*env\("DIRECT_URL"\)/);
});